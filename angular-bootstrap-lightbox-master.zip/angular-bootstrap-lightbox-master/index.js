require('./dist/angular-bootstrap-lightbox');
module.exports = 'angular-bootstrap-lightbox';
